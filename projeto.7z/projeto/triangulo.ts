const valor = require( 'readline-sync');

let ladoA:number = parseFloat(valor.question('Informe o lado A:'))
let ladoB:number = parseFloat(valor.question('Digite o lado B:'))
let ladoC:number = parseFloat(valor.question('Informe o ladoC:'))

if(ladoA>= ladoB + ladoC &&
        ladoB>= ladoA + ladoC &&
            ladoC>= ladoA + ladoC) {
                console.log("isso não é um triangulo");
                if(ladoA == ladoB && ladoB == ladoC ) {
                    console.log('triangulo equilatero')
                }
            }
        
        else if(ladoA==ladoB || ladoB==ladoC || ladoC==ladoA){
            console.log("isso é um triangulo isoceles")
        }
        else{
            console.log('triangulo escaleno')
        }