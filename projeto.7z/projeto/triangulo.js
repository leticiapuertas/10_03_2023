var valor = require('readline-sync');
var ladoA = parseFloat(valor.question('Informe o lado A:'));
var ladoB = parseFloat(valor.question('Digite o lado B:'));
var ladoC = parseFloat(valor.question('Informe o ladoC:'));
if (ladoA >= ladoB + ladoC &&
    ladoB >= ladoA + ladoC &&
    ladoC >= ladoA + ladoC) {
    console.log("isso não é um triangulo");
    if (ladoA == ladoB && ladoB == ladoC) {
        console.log('triangulo equilatero');
    }
}
else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA) {
    console.log("isso é um triangulo isoceles");
}
else {
    console.log('triangulo escaleno');
}
